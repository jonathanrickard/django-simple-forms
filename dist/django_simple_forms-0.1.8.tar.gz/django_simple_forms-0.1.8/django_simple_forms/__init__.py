default_app_config = 'django_simple_forms.apps.Config'
